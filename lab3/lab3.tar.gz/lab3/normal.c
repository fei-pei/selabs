#include<stdio.h>
#include<stdlib.h>
#include"menu.h"
static tLinkTable * head;

int Test1(tLinkTable * head);

int main()
{
    head =CreateLinkTable();
    InitCmd(head);
	AddCmd(head, "show","this is show cmd!", NULL, ENABLE);
	AddCmd(head,"test1", "for instance", Test1, ENABLE);
	Help(head);
	printf("the test1 will be delete.\n")
	getchar();
	DelCmd(head,"test1");
	Help(head);

    /* cmd line begins */
    MenuStart(head);

	return 0;
}
/* User can define the fuction like this */
int Test1(tLinkTable * head)
{
    printf("this is a good prgram!\n");
    return 0;
}
