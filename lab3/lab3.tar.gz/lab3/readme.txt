﻿1. 压缩包内已包含Makefile，在linux下编译时可直接用 'make' 命令。
2. 单元接口测试程序在testinterface.c中实现，测试桩为stub函数，在menu.c中定义，在testinterface.c中调用。
