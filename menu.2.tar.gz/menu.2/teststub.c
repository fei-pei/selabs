/**************************************************************************************************/
/* Copyright (C) Fuqiang Zhang, SSE@USTC, 2014-2015                                               */
/*                                                                                                */
/*  FILE NAME             :  teststub.c                                                           */
/*  PRINCIPAL AUTHOR      :  Fuqiang Zhang                                                        */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  testcase                                                             */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/28                                                           */
/*  DESCRIPTION           :  This is a teststub                                                   */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Fuqiang Zhang, 2014/09/28
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "menu.h"
#include "linktable.h"

/*create a menu */
int CreateMenu(tLinkTable* head,tDataNode data[])
{
    if(data->cmd!=NULL && data->desc!=NULL)
    {
        return 0;
    }
    return -1;
}

/* add a command */
int AddCmd(tLinkTable * p,char * cmd,char * desc)
{
    if(* cmd != '\0' && * desc != '\0')
    {
        return 0;
    }
    return -1;
}

/* search a command */
int SearchCmd(tLinkTable * head,char * cmd)
{
    if(head == '\0' ||  cmd == '\0')
    {
        return -1;
    }
    return 0;
}

/* delete a command */
int DelCmd(tLinkTable * p,char * cmd)
{
    if( * cmd == '\0')
    {
        return -1;
    }
    return 0;
}

/* Modify a command */
int ModCmd(tLinkTable * p,char * cmd,char * desc)
{
    if( * cmd == '\0' ||  * desc == '\0')
    {
        return -1;
    }
    return 0;
}

/* menu start */
int MenuStart(tLinkTable * tHead)
{
    if(tHead == NULL)
    {
        return -1;
    }
    return 0;
}

/* show all commands*/
int Help(tLinkTable * head)
{
    return 0;
}

/* quit the program */
int Quit(tLinkTable * head)
{
    return 0;
}
