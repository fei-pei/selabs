1 gcc linktable.c testcase.c teststub.c -o test
2 ./test

